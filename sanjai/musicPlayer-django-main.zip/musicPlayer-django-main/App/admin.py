from django.contrib import admin
from . models import Song


# Register your models here.
admin.site.register(Song)
